// Generated from uk/ac/imperial/pipe/parsers/RateGrammar.g4 by ANTLR 4.2
package uk.ac.imperial.pipe.parsers;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class RateGrammarParser extends Parser {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__6=1, T__5=2, T__4=3, T__3=4, T__2=5, T__1=6, T__0=7, ID=8, INT=9, DOUBLE=10, 
		WS=11, MUL=12, DIV=13, ADD=14, SUB=15;
	public static final String[] tokenNames = {
		"<INVALID>", "')'", "','", "'('", "'#('", "'ceil('", "'cap('", "'floor('", 
		"ID", "INT", "DOUBLE", "WS", "'*'", "'/'", "'+'", "'-'"
	};
	public static final int
		RULE_program = 0, RULE_expression = 1, RULE_capacity = 2, RULE_token_number = 3, 
		RULE_token_color_number = 4;
	public static final String[] ruleNames = {
		"program", "expression", "capacity", "token_number", "token_color_number"
	};

	@Override
	public String getGrammarFileName() { return "RateGrammar.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public RateGrammarParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ProgramContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitProgram(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitProgram(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(10); expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class AddOrSubtractContext extends ExpressionContext {
		public Token op;
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public AddOrSubtractContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterAddOrSubtract(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitAddOrSubtract(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitAddOrSubtract(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class MultOrDivContext extends ExpressionContext {
		public Token op;
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public MultOrDivContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterMultOrDiv(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitMultOrDiv(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitMultOrDiv(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FloorContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public FloorContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterFloor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitFloor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitFloor(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IntegerContext extends ExpressionContext {
		public TerminalNode INT() { return getToken(RateGrammarParser.INT, 0); }
		public IntegerContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterInteger(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitInteger(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitInteger(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CeilContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public CeilContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterCeil(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitCeil(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitCeil(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PlaceTokensContext extends ExpressionContext {
		public Token_numberContext token_number() {
			return getRuleContext(Token_numberContext.class,0);
		}
		public PlaceTokensContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterPlaceTokens(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitPlaceTokens(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitPlaceTokens(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PlaceColorTokensContext extends ExpressionContext {
		public Token_color_numberContext token_color_number() {
			return getRuleContext(Token_color_numberContext.class,0);
		}
		public PlaceColorTokensContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterPlaceColorTokens(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitPlaceColorTokens(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitPlaceColorTokens(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ParenExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ParenExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterParenExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitParenExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitParenExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class DoubleContext extends ExpressionContext {
		public TerminalNode DOUBLE() { return getToken(RateGrammarParser.DOUBLE, 0); }
		public DoubleContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterDouble(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitDouble(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitDouble(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PlaceCapacityContext extends ExpressionContext {
		public CapacityContext capacity() {
			return getRuleContext(CapacityContext.class,0);
		}
		public PlaceCapacityContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterPlaceCapacity(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitPlaceCapacity(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitPlaceCapacity(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		return expression(0);
	}

	private ExpressionContext expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExpressionContext _localctx = new ExpressionContext(_ctx, _parentState);
		ExpressionContext _prevctx = _localctx;
		int _startState = 2;
		enterRecursionRule(_localctx, 2, RULE_expression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(30);
			switch ( getInterpreter().adaptivePredict(_input,0,_ctx) ) {
			case 1:
				{
				_localctx = new ParenExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(13); match(3);
				setState(14); expression(0);
				setState(15); match(1);
				}
				break;

			case 2:
				{
				_localctx = new CeilContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(17); match(5);
				setState(18); expression(0);
				setState(19); match(1);
				}
				break;

			case 3:
				{
				_localctx = new FloorContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(21); match(7);
				setState(22); expression(0);
				setState(23); match(1);
				}
				break;

			case 4:
				{
				_localctx = new PlaceCapacityContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(25); capacity();
				}
				break;

			case 5:
				{
				_localctx = new PlaceTokensContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(26); token_number();
				}
				break;

			case 6:
				{
				_localctx = new PlaceColorTokensContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(27); token_color_number();
				}
				break;

			case 7:
				{
				_localctx = new IntegerContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(28); match(INT);
				}
				break;

			case 8:
				{
				_localctx = new DoubleContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(29); match(DOUBLE);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(40);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,2,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(38);
					switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
					case 1:
						{
						_localctx = new MultOrDivContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(32);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(33);
						((MultOrDivContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==MUL || _la==DIV) ) {
							((MultOrDivContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						consume();
						setState(34); expression(10);
						}
						break;

					case 2:
						{
						_localctx = new AddOrSubtractContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(35);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(36);
						((AddOrSubtractContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==ADD || _la==SUB) ) {
							((AddOrSubtractContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						consume();
						setState(37); expression(9);
						}
						break;
					}
					} 
				}
				setState(42);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,2,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class CapacityContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(RateGrammarParser.ID, 0); }
		public CapacityContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_capacity; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterCapacity(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitCapacity(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitCapacity(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CapacityContext capacity() throws RecognitionException {
		CapacityContext _localctx = new CapacityContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_capacity);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(43); match(6);
			setState(44); match(ID);
			setState(45); match(1);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Token_numberContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(RateGrammarParser.ID, 0); }
		public Token_numberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_token_number; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterToken_number(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitToken_number(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitToken_number(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Token_numberContext token_number() throws RecognitionException {
		Token_numberContext _localctx = new Token_numberContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_token_number);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(47); match(4);
			setState(48); match(ID);
			setState(49); match(1);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Token_color_numberContext extends ParserRuleContext {
		public List<TerminalNode> ID() { return getTokens(RateGrammarParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(RateGrammarParser.ID, i);
		}
		public Token_color_numberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_token_color_number; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).enterToken_color_number(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RateGrammarListener ) ((RateGrammarListener)listener).exitToken_color_number(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RateGrammarVisitor ) return ((RateGrammarVisitor<? extends T>)visitor).visitToken_color_number(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Token_color_numberContext token_color_number() throws RecognitionException {
		Token_color_numberContext _localctx = new Token_color_numberContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_token_color_number);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(51); match(4);
			setState(52); match(ID);
			setState(53); match(2);
			setState(54); match(ID);
			setState(55); match(1);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 1: return expression_sempred((ExpressionContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expression_sempred(ExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0: return precpred(_ctx, 9);

		case 1: return precpred(_ctx, 8);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\21<\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\3\2\3\2\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3!\n\3\3\3\3\3\3\3\3\3\3\3\3\3"+
		"\7\3)\n\3\f\3\16\3,\13\3\3\4\3\4\3\4\3\4\3\5\3\5\3\5\3\5\3\6\3\6\3\6\3"+
		"\6\3\6\3\6\3\6\2\3\4\7\2\4\6\b\n\2\4\3\2\16\17\3\2\20\21?\2\f\3\2\2\2"+
		"\4 \3\2\2\2\6-\3\2\2\2\b\61\3\2\2\2\n\65\3\2\2\2\f\r\5\4\3\2\r\3\3\2\2"+
		"\2\16\17\b\3\1\2\17\20\7\5\2\2\20\21\5\4\3\2\21\22\7\3\2\2\22!\3\2\2\2"+
		"\23\24\7\7\2\2\24\25\5\4\3\2\25\26\7\3\2\2\26!\3\2\2\2\27\30\7\t\2\2\30"+
		"\31\5\4\3\2\31\32\7\3\2\2\32!\3\2\2\2\33!\5\6\4\2\34!\5\b\5\2\35!\5\n"+
		"\6\2\36!\7\13\2\2\37!\7\f\2\2 \16\3\2\2\2 \23\3\2\2\2 \27\3\2\2\2 \33"+
		"\3\2\2\2 \34\3\2\2\2 \35\3\2\2\2 \36\3\2\2\2 \37\3\2\2\2!*\3\2\2\2\"#"+
		"\f\13\2\2#$\t\2\2\2$)\5\4\3\f%&\f\n\2\2&\'\t\3\2\2\')\5\4\3\13(\"\3\2"+
		"\2\2(%\3\2\2\2),\3\2\2\2*(\3\2\2\2*+\3\2\2\2+\5\3\2\2\2,*\3\2\2\2-.\7"+
		"\b\2\2./\7\n\2\2/\60\7\3\2\2\60\7\3\2\2\2\61\62\7\6\2\2\62\63\7\n\2\2"+
		"\63\64\7\3\2\2\64\t\3\2\2\2\65\66\7\6\2\2\66\67\7\n\2\2\678\7\4\2\289"+
		"\7\n\2\29:\7\3\2\2:\13\3\2\2\2\5 (*";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}