// Generated from uk/ac/imperial/pipe/parsers/RateGrammar.g4 by ANTLR 4.2
package uk.ac.imperial.pipe.parsers;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link RateGrammarParser}.
 */
public interface RateGrammarListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#addOrSubtract}.
	 * @param ctx the parse tree
	 */
	void enterAddOrSubtract(@NotNull RateGrammarParser.AddOrSubtractContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#addOrSubtract}.
	 * @param ctx the parse tree
	 */
	void exitAddOrSubtract(@NotNull RateGrammarParser.AddOrSubtractContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#integer}.
	 * @param ctx the parse tree
	 */
	void enterInteger(@NotNull RateGrammarParser.IntegerContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#integer}.
	 * @param ctx the parse tree
	 */
	void exitInteger(@NotNull RateGrammarParser.IntegerContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#ceil}.
	 * @param ctx the parse tree
	 */
	void enterCeil(@NotNull RateGrammarParser.CeilContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#ceil}.
	 * @param ctx the parse tree
	 */
	void exitCeil(@NotNull RateGrammarParser.CeilContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#token_color_number}.
	 * @param ctx the parse tree
	 */
	void enterToken_color_number(@NotNull RateGrammarParser.Token_color_numberContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#token_color_number}.
	 * @param ctx the parse tree
	 */
	void exitToken_color_number(@NotNull RateGrammarParser.Token_color_numberContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#double}.
	 * @param ctx the parse tree
	 */
	void enterDouble(@NotNull RateGrammarParser.DoubleContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#double}.
	 * @param ctx the parse tree
	 */
	void exitDouble(@NotNull RateGrammarParser.DoubleContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#token_number}.
	 * @param ctx the parse tree
	 */
	void enterToken_number(@NotNull RateGrammarParser.Token_numberContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#token_number}.
	 * @param ctx the parse tree
	 */
	void exitToken_number(@NotNull RateGrammarParser.Token_numberContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#multOrDiv}.
	 * @param ctx the parse tree
	 */
	void enterMultOrDiv(@NotNull RateGrammarParser.MultOrDivContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#multOrDiv}.
	 * @param ctx the parse tree
	 */
	void exitMultOrDiv(@NotNull RateGrammarParser.MultOrDivContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#floor}.
	 * @param ctx the parse tree
	 */
	void enterFloor(@NotNull RateGrammarParser.FloorContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#floor}.
	 * @param ctx the parse tree
	 */
	void exitFloor(@NotNull RateGrammarParser.FloorContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(@NotNull RateGrammarParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(@NotNull RateGrammarParser.ProgramContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#placeTokens}.
	 * @param ctx the parse tree
	 */
	void enterPlaceTokens(@NotNull RateGrammarParser.PlaceTokensContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#placeTokens}.
	 * @param ctx the parse tree
	 */
	void exitPlaceTokens(@NotNull RateGrammarParser.PlaceTokensContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#placeColorTokens}.
	 * @param ctx the parse tree
	 */
	void enterPlaceColorTokens(@NotNull RateGrammarParser.PlaceColorTokensContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#placeColorTokens}.
	 * @param ctx the parse tree
	 */
	void exitPlaceColorTokens(@NotNull RateGrammarParser.PlaceColorTokensContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#capacity}.
	 * @param ctx the parse tree
	 */
	void enterCapacity(@NotNull RateGrammarParser.CapacityContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#capacity}.
	 * @param ctx the parse tree
	 */
	void exitCapacity(@NotNull RateGrammarParser.CapacityContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#parenExpression}.
	 * @param ctx the parse tree
	 */
	void enterParenExpression(@NotNull RateGrammarParser.ParenExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#parenExpression}.
	 * @param ctx the parse tree
	 */
	void exitParenExpression(@NotNull RateGrammarParser.ParenExpressionContext ctx);

	/**
	 * Enter a parse tree produced by {@link RateGrammarParser#placeCapacity}.
	 * @param ctx the parse tree
	 */
	void enterPlaceCapacity(@NotNull RateGrammarParser.PlaceCapacityContext ctx);
	/**
	 * Exit a parse tree produced by {@link RateGrammarParser#placeCapacity}.
	 * @param ctx the parse tree
	 */
	void exitPlaceCapacity(@NotNull RateGrammarParser.PlaceCapacityContext ctx);
}