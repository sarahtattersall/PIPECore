// Generated from uk/ac/imperial/pipe/parsers/RateGrammar.g4 by ANTLR 4.2
package uk.ac.imperial.pipe.parsers;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link RateGrammarParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface RateGrammarVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#addOrSubtract}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAddOrSubtract(@NotNull RateGrammarParser.AddOrSubtractContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#integer}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInteger(@NotNull RateGrammarParser.IntegerContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#ceil}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCeil(@NotNull RateGrammarParser.CeilContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#token_color_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitToken_color_number(@NotNull RateGrammarParser.Token_color_numberContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#double}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDouble(@NotNull RateGrammarParser.DoubleContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#token_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitToken_number(@NotNull RateGrammarParser.Token_numberContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#multOrDiv}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultOrDiv(@NotNull RateGrammarParser.MultOrDivContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#floor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloor(@NotNull RateGrammarParser.FloorContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(@NotNull RateGrammarParser.ProgramContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#placeTokens}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlaceTokens(@NotNull RateGrammarParser.PlaceTokensContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#placeColorTokens}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlaceColorTokens(@NotNull RateGrammarParser.PlaceColorTokensContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#capacity}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCapacity(@NotNull RateGrammarParser.CapacityContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#parenExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenExpression(@NotNull RateGrammarParser.ParenExpressionContext ctx);

	/**
	 * Visit a parse tree produced by {@link RateGrammarParser#placeCapacity}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlaceCapacity(@NotNull RateGrammarParser.PlaceCapacityContext ctx);
}